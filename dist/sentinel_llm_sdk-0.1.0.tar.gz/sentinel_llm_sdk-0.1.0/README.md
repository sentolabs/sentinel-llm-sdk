# Sentinel SDK

The universal AI-to-physical world SDK. Control any device with natural language.
